##############################################################################################################################
# File Name: Update_Child_Table_Names.py
# Author: Justin L. Welty
# Created: April 30th, 2018
# Last Modified: May 8th, 2018
# Python Modules Required: arcpy.
#Purpose: Updates child table project names in the event that a parent name was updated 
##############################################################################################################################

# Import the arcpy module or throw error if the module isn't found
try:
    import arcpy #Try to import acrpy
except: 
    arcpy.AddError('Error: arcpy module not found, process terminated') # Add an error message if import arcpy fails
    sys.exit() # Exit the script

# Set the geodatabase where the actions will take place.
gdb = arcpy.GetParameterAsText(0)

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script
    else:
        infields = ['Project_Name']
        with arcpy.da.SearchCursor(tbl, infields) as cursor:
            for row in cursor:
                prjname = row[0]
                cnt = 0
                for tbl1 in intables:
                    infields1 = ['Project_Name']
                    with arcpy.da.SearchCursor(tbl1, infields1) as cursor1:
                        for row1 in cursor1:
                            prjname1 = row1[0]

                            if prjname == prjname1:
                                cnt = cnt + 1
                if cnt > 1:
                    arcpy.AddError("Project Name '" + str(prjname) + "' is duplicated across multiple records in the 3 CED batch update main tables ('CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans'). Please ensure all efforts have unique project names. The error code is terminating.")
                    sys.exit()

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name']
# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName']

for tbl in intables: #Loop through all the input tables
    arcpy.AddMessage("Updating project names for parent table: " + str(tbl))
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                childtbls = ['CED_1_Child_Table_Spatial_Project_Objectives', 'CED_1_Child_Table_Spatial_Project_Methods', 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements', 'CED_1_Child_Table_Effectiveness_PECE_Questions', 'CED_1_Child_Table_Implementation_PECE_Questions', 'CED_1_Child_Table_Spatial_Project_Collaborators', 'CED_1_Child_Table_Spatial_Project_Land_Owners', 'CED_1_Child_Table_Spatial_Project_Threats', 'CED_1_Child_Table_Spatial_Project_Documentation']
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                childtbls = ['CED_2_Child_Table_NonSpatial_Project_Objectives', 'CED_2_Child_Table_NonSpatial_Project_Methods', 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements', 'CED_2_Child_Table_NonSpatial_Project_Collaborators', 'CED_2_Child_Table_NonSpatial_Project_Counties', 'CED_2_Child_Table_NonSpatial_Project_Land_Owners', 'CED_2_Child_Table_NonSpatial_Project_Threats', 'CED_2_Child_Table_NonSpatial_Project_Documentation']
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                childtbls = ['CED_3_Child_Table_NonSpatial_Plan_Collaborators', 'CED_3_Child_Table_NonSpatial_Plan_Counties', 'CED_3_Child_Table_NonSpatial_Plan_Land_Owners', 'CED_3_Child_Table_NonSpatial_Plan_Threats', 'CED_3_Child_Table_NonSpatial_Plan_Documentation']

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The update name code is terminating. Please ensure all records have project names.")
                sys.exit()

            for ctbl in childtbls: #Loop through all the child tables and update the names
                edit = arcpy.da.Editor(gdb)
                edit.startEditing(False, True)
                edit.startOperation()

                with arcpy.da.UpdateCursor(ctbl, outfields) as ucursor:
                    for urow in ucursor:
                        if int(urow[0]) == int(prjid):
                            urow[1] = prjnm
                            # Update the cursor with the updated name
                            ucursor.updateRow(urow)

                    del ucursor # Delete ucursor
                edit.stopOperation()
                edit.stopEditing(True)
    del cursor  # Delete cursor

arcpy.AddMessage("Process complete, all names successfully updated")

