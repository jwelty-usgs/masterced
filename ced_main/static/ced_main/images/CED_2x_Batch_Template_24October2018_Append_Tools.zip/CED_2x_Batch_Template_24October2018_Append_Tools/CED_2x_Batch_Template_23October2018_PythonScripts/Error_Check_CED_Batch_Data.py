##############################################################################################################################
# File Name: Create_Threatss.py
# Author: Justin L. Welty
# Created: April 30th, 2018
# Last Modified: May 8th, 2018
# Python Modules Required: arcpy.
#Purpose: Create all necessary child records for CED efforts based specific fields within the parent tables. 
##############################################################################################################################

# Import the arcpy module or throw error if the module isn't found
import sys
try:
    import arcpy #Try to import acrpy
except: 
    arcpy.AddError('Error: arcpy module not found, process terminated') # Add an error message if import arcpy fails
    sys.exit() # Exit the script

import datetime
now = datetime.datetime.now()
curyear = now.year

# Set the geodatabase where the actions will take place.
gdb = arcpy.GetParameterAsText(0)


arcpy.AddMessage("You are conducting a full CED Batch upload error check")
arcpy.AddMessage("This process may take some time depending on the number of records, please be patient.")
arcpy.AddWarning("All errors will be printed on the screen as error messages (red text) and added to the CED_Error_Log table located within this geodatabase. Warnings will be printed as green text and may or may not be added to the error log depending on their severity. The CED_Error_Log table also has a 'Resolved' field allowing you to confirm when an error has been resolved.")
arcpy.AddMessage("Starting Error Check")


arcpy.env.workspace = gdb

# Set the error record
errortable = "CED_Error_Log" # Set error table
arcpy.DeleteRows_management(errortable)
outfields = ['Table_Name', 'RecordObjectID', 'RecordGlobalID', 'Project_Name', 'Error_Type', 'Error_Description', 'ParentObjectID', 'ParentGlobalID', 'Resolved']
cursorerror = arcpy.da.InsertCursor(errortable, outfields) #Set the Error Cursor



###################################################################################################################################################
### Collaborators
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberCollaborators', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']
arcpy.AddMessage("Step 1: Looking for duplicate project names")
for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script
    else:  

        infields = ['Project_Name']
        with arcpy.da.SearchCursor(tbl, infields) as cursor:
            for row in cursor:
                prjname = row[0]
                cnt = 0
                for tbl1 in intables:
                    infields1 = ['Project_Name']
                    with arcpy.da.SearchCursor(tbl1, infields1) as cursor1:
                        for row1 in cursor1:
                            prjname1 = row1[0]

                            if prjname == prjname1:
                                cnt = cnt + 1
                if cnt > 1:
                    arcpy.AddError("Project Name '" + str(prjname) + "' is duplicated across multiple records in the 3 CED batch update main tables ('CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans'). Please ensure all efforts have unique project names. The error code is terminating.")
                    sys.exit()



arcpy.AddMessage("Step 2: Looking for missing records in child tables")

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberCollaborators', 'GlobalID']
# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

testcnt = 1
for tbl in intables: #Loop through all the input tables
    # edit = arcpy.da.Editor(gdb)
    # edit.startEditing(False, True)
    # edit.startOperation()
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:

            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Collaborators'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Collaborators'
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                outtable = 'CED_3_Child_Table_NonSpatial_Plan_Collaborators'
            NoneSel = 0

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The error code is terminating.")
                sys.exit()

            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(1) # Assign 1 if no data entered
                NoneSel = 1 # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddError("There are " + str(extrarows) + " extra collaborator records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + str(outtable) + ". You must have reduced the number of collaborator records for this effort. Please manually delete the collaborator rows for this effort that not longer apply. The error check will terminate until the issue is resolved.")
                sys.exit()

            # if arcpy.Exists("outtable_view"): # If the table view exists
            #     arcpy.Delete_management("outtable_view") # Delete the table view

            if NoneSel == 0:
                if newrec > 0: # Determine if new records need to be added to the table
                    arcpy.AddWarning("New collaborator records created in " + outtable + " for ID: " + str(prjid) + ", Name: " + str(prjnm) + " = " + str(newrec) + " records. These records will need to be completed.")
                    cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                    
                    for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                        cursor1.insertRow((prjid, prjnm, gblid))

                    del cursor1 # Delete cursor1

            else:
                if newrec > 0: # Determine if new records need to be added to the table
                    outfields1 = ['PrjID', 'PrjName', 'Collaborator', 'ParentGlobalID']
                    arcpy.AddWarning("New collaborator records created in " + outtable + " for ID: " + str(prjid) + ", Name: " + str(prjnm) + " = " + str(newrec) + " records. These records will need to be completed.")
                    cursor1 = arcpy.da.InsertCursor(outtable, outfields1) #Set the Insert Cursor
                    
                    for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                        cursor1.insertRow((prjid, prjnm, 10, gblid))

                    del cursor1 # Delete cursor1
                elif existrec == 1:
                    outfields1 = ['PrjID', 'PrjName', 'Collaborator', 'ParentGlobalID']
                    with arcpy.da.UpdateCursor(outtable, outfields1, " PrjID = " + str(prjid) + " ") as cursor1:
                        for row1 in cursor1:
                            row1[2] = 10
                            cursor1.updateRow(row1) 
                    del cursor1
                else:
                    arcpy.AddError("For ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + ", you selected a Null value indicating None for collaborators. However, " + str(existrec) + " with data still exist for this effort in " + outtable + ", please delete all but one collaborator row for this effort, set the value to 'None' and run the tool again.  The error check will terminate until the issue is resolved.")
                    sys.exit()

    # edit.stopOperation()
    # edit.stopEditing(True)
    del cursor  # Delete cursor


###################################################################################################################################################
### Objectives
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberofObjectives', 'GlobalID', 'SubActivity']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'SubActivity', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Objectives'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Objectives'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            subact = row[4] # Get the subactivity
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddError("There are " + str(extrarows) + " extra objective records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of objective records for this effort. Please manually delete the objective rows for this effort that not longer apply. The error check will terminate until the issue is resolved.")
                sys.exit()

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if newrec > 0: # Determine if new records need to be added to the table
                arcpy.AddWarning("New objectives records created in " + outtable + " for: " + str(prjnm) + " = " + str(newrec) + " records. These records will need to be completed.")
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, subact, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor


###################################################################################################################################################
### Methods
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberofMethods', 'GlobalID', 'SubActivity']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'SubActivity', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Methods'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Methods'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            subact = row[4] # Get the subactivity
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddError("There are " + str(extrarows) + " extra method records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of method records for this effort. Please manually delete the method rows for this effort that not longer apply. The error check will terminate until the issue is resolved.")
                sys.exit()

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if newrec > 0: # Determine if new records need to be added to the table
                arcpy.AddWarning("New methods records created in " + outtable + " for: " + str(prjnm) + " = " + str(newrec) + " records. These records will need to be completed.")
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, subact, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor


###################################################################################################################################################
### Effectiveness Statements
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberofEffectiveStates', 'GlobalID', 'Effect_Status', 'SubActivity']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'SubActivity', 'Effectiveness_Status', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            subact = row[5] # Get the subactivity
            effect = row[4] # Get the effectiveness
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddError("There are " + str(extrarows) + " extra Effectiveness Statements created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of effectiveness statement records for this effort. Please manually delete the effectiveness statement rows for this effort that not longer apply. The error check will terminate until the issue is resolved.")
                sys.exit()

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view
            if newrec > 0: # Determine if new records need to be added to the table
                arcpy.AddWarning("New effectiveness statement records created in " + outtable + " for: " + str(prjnm) + " = " + str(newrec) + " records. These records will need to be completed.")
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, subact, effect, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor

###################################################################################################################################################
### Land Owners
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberLandOwners', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script


# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Land_Owners'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Land_Owners'
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                outtable = 'CED_3_Child_Table_NonSpatial_Plan_Land_Owners'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The error code is terminating.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddError("There are " + str(extrarows) + " extra land owner records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of land owner records for this effort. Please manually delete the land owner rows for this effort that not longer apply. The error check will terminate until the issue is resolved.")
                sys.exit()

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if newrec > 0: # Determine if new records need to be added to the table
                arcpy.AddWarning("New land ownership records created in " + outtable + " for: " + str(prjnm) + " = " + str(newrec) + " records. These records will need to be completed.")
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor

###################################################################################################################################################
### Threats
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberThreatsAddress', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script


# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Threats'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Threats'
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                outtable = 'CED_3_Child_Table_NonSpatial_Plan_Threats'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The error code is terminating.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddError("There are " + str(extrarows) + " extra threat records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of threat records for this effort. Please manually delete the threat rows for this effort that not longer apply. The error check will terminate until the issue is resolved.")
                sys.exit()

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if newrec > 0: # Determine if new records need to be added to the table
                arcpy.AddWarning("New threat records created in " + outtable + " for ID: " + str(prjid) + ", Name: " + str(prjnm) + " = " + str(newrec) + " records. These records will need to be completed.")
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor

###################################################################################################################################################
### Effectiveness PECE
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'Effect_Status', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script


# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Effectiveness_PECE_Questions'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The error code is terminating.")
                sys.exit()
            try:
                eff = int(row[2]) # Get the number of threats to be created for the project
            except:
                eff = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable

            if existrec > 0: 
                if eff == 1:
                    arcpy.DeleteRows_management("outtable_view")
                    arcpy.AddWarning("Effectiveness PECE record exists and is no longer required for ID: " + str(prjid) + ", Name: " + str(prjnm) + ". The record has been deleted.")
                elif eff == 2 or eff == 3:
                    a = 1
            else:
                if eff == 1:
                    a = 1
                elif eff == 2 or eff == 3:
                    cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                    cursor1.insertRow((prjid, prjnm, gblid))
                    del cursor1 # Delete cursor1
                    arcpy.AddWarning("New effectiveness PECE record created in " + outtable + ". for ID: " + str(prjid) + ", Name: " + str(prjnm) + ". This record will need to be completed.")

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view
                
            

    del cursor  # Delete cursor

###################################################################################################################################################
### Implementation PECE
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'Entry_Status', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script


# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Implementation_PECE_Questions'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The error code is terminating.")
                sys.exit()
            try:
                imp = int(row[2]) # Get the number of threats to be created for the project
            except:
                imp = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable

            if existrec > 0: 
                if imp == 3:
                    arcpy.DeleteRows_management("outtable_view")
                    arcpy.AddWarning("Implementation PECE record exists and is no longer required for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ". The record has been deleted.")
                elif imp == 2:
                    a = 1
            else:
                if imp == 3:
                    a = 1
                elif imp == 2:
                    cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                    cursor1.insertRow((prjid, prjnm, gblid))
                    del cursor1 # Delete cursor1
                    arcpy.AddWarning("New implementation PECE record created in " + outtable + ". for ID: " + str(prjid) + ", Name: " + str(prjnm) + ". This record will need to be completed.")

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view
                
            

    del cursor  # Delete cursor


###################################################################################################################################################
### Counties
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberCounties', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script


# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Counties'
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                outtable = 'CED_3_Child_Table_NonSpatial_Plan_Counties'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddWarning("There are " + str(extrarows) + " extra county records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of county records for this effort. Please manually delete the county rows for this effort that not longer apply. The error check will terminate until the issue is resolved.")
                sys.exit()

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            
            if newrec > 0: # Determine if new records need to be added to the table
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                arcpy.AddWarning("New county records created in " + outtable + " for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " = " + str(newrec) + " records")
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor

###################################################################################################################################################
### Documentation
###################################################################################################################################################
# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberDocs', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script


# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Documentation'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Documentation'
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                outtable = 'CED_3_Child_Table_NonSpatial_Plan_Documentation'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The error code is terminating.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if newrec > 0: # Determine if new records need to be added to the table
                arcpy.AddWarning("New document records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + " = " + str(newrec) + " records. These records will need to be completed.")

                temptable = gdb.replace('CED_2x_Batch_Template_23October2018.gdb','CED_2x_Batch_Template_23October2018_PythonScripts\CED_2x_Batch_Template_Temp_Files.gdb\Temporary_Documentation_Table')
                cursor1 = arcpy.da.InsertCursor(temptable, outfields) #Set the Insert Cursor
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    
                    cursor1.insertRow((prjid, prjnm, gblid))

                del cursor1 # Delete cursor1

                arcpy.Append_management(temptable, outtable, "NO_TEST")

                arcpy.DeleteRows_management(temptable)

    del cursor  # Delete cursor

#Update all names and subactivities
arcpy.AddMessage("Step 3: Double checking and correcting all project names and subactivites in child tables")

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script
    else:
        infields = ['Project_Name']
        with arcpy.da.SearchCursor(tbl, infields) as cursor:
            for row in cursor:
                prjname = row[0]
                cnt = 0
                for tbl1 in intables:
                    infields1 = ['Project_Name']
                    with arcpy.da.SearchCursor(tbl1, infields1) as cursor1:
                        for row1 in cursor1:
                            prjname1 = row1[0]

                            if prjname == prjname1:
                                cnt = cnt + 1
                if cnt > 1:
                    arcpy.AddError("Project Name '" + str(prjname) + "' is duplicated across multiple records in the 3 CED batch update main tables ('CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans'). Please ensure all efforts have unique project names. The error code is terminating.")
                    sys.exit()

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name']
# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                childtbls = ['CED_1_Child_Table_Spatial_Project_Objectives', 'CED_1_Child_Table_Spatial_Project_Methods', 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements', 'CED_1_Child_Table_Effectiveness_PECE_Questions', 'CED_1_Child_Table_Implementation_PECE_Questions', 'CED_1_Child_Table_Spatial_Project_Collaborators', 'CED_1_Child_Table_Spatial_Project_Land_Owners', 'CED_1_Child_Table_Spatial_Project_Threats', 'CED_1_Child_Table_Spatial_Project_Documentation']
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                childtbls = ['CED_2_Child_Table_NonSpatial_Project_Objectives', 'CED_2_Child_Table_NonSpatial_Project_Methods', 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements', 'CED_2_Child_Table_NonSpatial_Project_Collaborators', 'CED_2_Child_Table_NonSpatial_Project_Counties', 'CED_2_Child_Table_NonSpatial_Project_Land_Owners', 'CED_2_Child_Table_NonSpatial_Project_Threats', 'CED_2_Child_Table_NonSpatial_Project_Documentation']
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                childtbls = ['CED_3_Child_Table_NonSpatial_Plan_Collaborators', 'CED_3_Child_Table_NonSpatial_Plan_Counties', 'CED_3_Child_Table_NonSpatial_Plan_Land_Owners', 'CED_3_Child_Table_NonSpatial_Plan_Threats', 'CED_3_Child_Table_NonSpatial_Plan_Documentation']

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The update name code is terminating. Please ensure all records have project names.")
                sys.exit()

            for ctbl in childtbls: #Loop through all the child tables and update the names
                edit = arcpy.da.Editor(gdb)
                edit.startEditing(False, True)
                edit.startOperation()

                with arcpy.da.UpdateCursor(ctbl, outfields) as ucursor:
                    for urow in ucursor:
                        if int(urow[0]) == int(prjid):
                            urow[1] = prjnm
                            # Update the cursor with the updated name
                            ucursor.updateRow(urow)

                    del ucursor # Delete ucursor
                edit.stopOperation()
                edit.stopEditing(True)
    del cursor  # Delete cursor

#Check all of the subactivites in child tables where they exist
intables1 = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects']
# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'SubActivity']
# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'SubActivity']
for tbl1 in intables1: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl1, infields) as cursor:
        for row in cursor:
            if tbl1 == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                childtbls = ['CED_1_Child_Table_Spatial_Project_Objectives', 'CED_1_Child_Table_Spatial_Project_Methods', 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements']
            elif tbl1 == 'CED_2_Batch_Template_NonSpatial_Projects':
                childtbls = ['CED_2_Child_Table_NonSpatial_Project_Objectives', 'CED_2_Child_Table_NonSpatial_Project_Methods', 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements']
            

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The update name code is terminating. Please ensure all records have project names.")
                sys.exit()

            for ctbl in childtbls: #Loop through all the child tables and update the names
                edit = arcpy.da.Editor(gdb)
                edit.startEditing(False, True)
                edit.startOperation()

                with arcpy.da.UpdateCursor(ctbl, outfields) as ucursor:
                    for urow in ucursor:
                        if int(urow[0]) == int(prjid):
                            urow[1] = prjnm
                            # Update the cursor with the updated name
                            ucursor.updateRow(urow)

                    del ucursor # Delete ucursor
                edit.stopOperation()
                edit.stopEditing(True)
    del cursor  # Delete cursor

# Loop through all the tables and identify missing values or incorrect field values

arcpy.AddMessage("Step 4: Looking for incorrect or incomplete data within fields")
errorcount = 0
warningcount = 0
# List of tables
tables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_1_Child_Table_Spatial_Project_Objectives', 'CED_1_Child_Table_Spatial_Project_Methods', 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements', 'CED_1_Child_Table_Effectiveness_PECE_Questions', 'CED_1_Child_Table_Implementation_PECE_Questions', 'CED_1_Child_Table_Spatial_Project_Collaborators', 'CED_1_Child_Table_Spatial_Project_Documentation', 'CED_1_Child_Table_Spatial_Project_Land_Owners', 'CED_1_Child_Table_Spatial_Project_Threats', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_2_Child_Table_NonSpatial_Project_Objectives', 'CED_2_Child_Table_NonSpatial_Project_Methods', 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements', 'CED_2_Child_Table_NonSpatial_Project_Collaborators', 'CED_2_Child_Table_NonSpatial_Project_Counties', 'CED_2_Child_Table_NonSpatial_Project_Documentation', 'CED_2_Child_Table_NonSpatial_Project_Land_Owners', 'CED_2_Child_Table_NonSpatial_Project_Threats', 'CED_3_Batch_Template_NonSpatial_Plans', 'CED_3_Child_Table_NonSpatial_Plan_Collaborators', 'CED_3_Child_Table_NonSpatial_Plan_Counties', 'CED_3_Child_Table_NonSpatial_Plan_Documentation', 'CED_3_Child_Table_NonSpatial_Plan_Land_Owners', 'CED_3_Child_Table_NonSpatial_Plan_Threats']

arcpy.env.workspace = gdb # Set the workspace

for table in tables: # Loop through the tables
    arcpy.AddMessage('Checking table:' + table)
    fields = arcpy.ListFields(table) # Identify fields in the table
    infields = []

    cnt = 0
    pgblexist = 0
    prjexist = 0
    for field in fields: # Loop through the fields in the table
        infields.append(field.name) # Add the fields to the field list

        if field.name == "GlobalID":
            cntgblid = cnt
        if field.name == "ParentGlobalID":
            cntpgblid = cnt
            pgblexist = 1
        if field.name == "Project_Name" or field.name == "PrjName":
            cntprjnm = cnt
        if field.name == "OBJECTID":
            cntobjid = cnt
        if field.name == "PrjID":
            cntprjid = cnt
            prjexist = 1
        if field.name == "SubActivity":
            cntsubact = cnt
            subactexist = 1
        if field.name == "Effectiveness_Status":
            cnteffect = cnt
            effectexist = 1
        cnt = cnt + 1




    with arcpy.da.SearchCursor(table, infields) as cursor: # Search through all records in the table
        for row in cursor: # Loop through each record
            gblid = row[cntgblid]
            if pgblexist == 1:
                pgblid = row[cntpgblid]
            if prjexist == 1:
                pobjid = row[cntprjid]
            prjnm = row[cntprjnm]
            objid = row[cntobjid]

            # Check CED_1_Batch_Template_Spatial_Projects
            if table == 'CED_1_Batch_Template_Spatial_Projects':
                if float(row[23]) <= 0:
                    arcpy.AddError('Error: ' + table + ' - Spatial data is missing for a spatial effort, ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Spatial data is missing for spatial effort', None, '', 'No'))
                    errorcount = errorcount + 1
                if str(row[2]) == '' or str(row[2]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Project Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Project Name is required', None, '', 'No'))
                    errorcount = errorcount + 1
                if str(row[3]) == 'None' or (int(row[3]) < 2 or int(row[3])) > 3:
                    arcpy.AddError('Error: ' + table + ' - Effort Status is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effort Status is required', None, '', 'No'))
                    errorcount = errorcount + 1
                if str(row[4]) == 'None' or (int(row[4]) < 9 or int(row[4])) > 11:
                    arcpy.AddError('Error: ' + table + ' - Spatial Activity is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Spatial Activity is required', None, '', 'No'))
                    errorcount = errorcount + 1


                if int(row[4]) == 10:
                    # Determine whether a fire related answer is required and missing
                    if str(row[6]) != 'Yes' and str(row[6]) != 'No':
                        arcpy.AddError('Error: ' + table + ' - Fire related Yes or No answer is required for ObjectID: ' + str(row[0]) + ' with a RESTORATION: Post-Disturbance and-or Habitat Enhancement Activity')
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Fire related Yes or No answer is required with a RESTORATION: Post-Disturbance and-or Habitat Enhancement Activity', None, '', 'No'))
                        errorcount = errorcount + 1

                    # Determine whether a seeding type answer is required and missing
                    if str(row[7]) != 'Only Native' and str(row[7]) != 'Only Non-Native' and str(row[7]) != 'Native/Non-Native Mixed' and str(row[7]) != 'No Seeding':
                        arcpy.AddError('Error: ' + table + ' - A seeding type or "No Seeding" is required for ObjectID: ' + str(row[0]) + ' with a RESTORATION: Post-Disturbance and-or Habitat Enhancement Activity')
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'A seeding type or "No Seeding" is required with a RESTORATION: Post-Disturbance and-or Habitat Enhancement Activity', None, '', 'No'))
                        errorcount = errorcount + 1

                # Ensure mitigation status exists
                if str(row[28]) == 'None':
                    
                    arcpy.AddError('Error: ' + table + ' - Mitigation status is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Mitigation status is required', None, '', 'No'))
                    errorcount = errorcount + 1

                # Ensure dates exist and start date occurs before end date
                if str(row[8]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Start Date is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Start Date is required', None, '', 'No'))
                    errorcount = errorcount + 1

                if  str(row[9]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - End Date is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'End Date is required', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[8]) != 'None' and str(row[9]) != 'None'and row[8] > row[9]:
                    arcpy.AddError('Error: ' + table + ' - End Date cannot occur before Start Date for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'End Date cannot occur before Start Date', None, '', 'No'))
                    errorcount = errorcount + 1

                #Check metric, metric value, GIS acres, and ensure GIS acres and metric value are close to each other
                if str(row[10]) == 'None' or str(row[10]) == "":
                    arcpy.AddError('Error: ' + table + ' - Metric Type is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Metric Type is required', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[11]) == 'None' or row[11] > 0:
                    arcpy.AddError('Error: ' + table + ' - Metric Value is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Metric Value is required', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[12]) == 'None' or int(row[12]) <= 0:
                    arcpy.AddError('Error: ' + table + ' - GIS Acres is required for ObjectID: ' + str(row[0]) + ' Please use "Calculate Geometry" to calculate the GIS Acres')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'GIS Acres is required Please use "Calculate Geometry" to calculate the GIS Acres', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[11]) != 'None' and str(row[12]) != 'None': 
                    if int(row[11]) > int(row[12]):
                        arcpy.AddWarning('Warning: ' + table + ' - GIS Acres are less then reported acres for ObjectID: ' + str(row[0]) + ' Please ensure these values represent the correct area where the conservation action was implemented. We caution including adjacent acres that may receive indirect benefit, if they are not included in the project-treatment area.')
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Warning', 'GIS Acres are less then reported acres. Please ensure these values represent the correct area where the conservation action was implemented.', None, '', 'No'))
                        warningcount = warningcount + 1

                    if int(row[12]) > int(row[11]):
                        AcrePer = int(row[11]) / int(row[12]) * 100
                        AcrePer = int(AcrePer) - 100
                        AcrePer = abs(AcrePer)
                        if AcrePer < 25 and AcrePer >= 1:
                            arcpy.AddWarning('Warning: ' + table + ' - GIS Acres are between 1 and 25 percent greater than the reported acres for ObjectID: ' + str(row[0]) + ' Please ensure these values represent the correct area where the conservation action was implemented. We caution including adjacent acres that may receive indirect benefit, if they are not included in the project-treatment area.')
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Warning', 'GIS Acres between 1 and 25 percent greater than the reported acres. Please ensure these values represent the correct area where the conservation action was implemented.', None, '', 'No'))
                            warningcount = warningcount + 1
                        elif AcrePer >= 25:
                            arcpy.AddError('Warning: ' + table + ' - Reported Acres are less than 75 percent of the GIS Acres for ObjectID: ' + str(row[0]) + ' A value with this much difference between GIS and reported is not allowed. Please ensure these values represent the correct area where the conservation action was implemented. We caution including adjacent acres that may receive indirect benefit, if they are not included in the project-treatment area.')
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Warning', 'Reported Acres are less than 75 percent of the GIS Acres. A value with this much difference between GIS and reported is not allowed. Please ensure these values represent the correct area where the conservation action was implemented.', None, '', 'No'))
                            errorcount = errorcount + 1

                # Ensure a valid Implementing Party is selected
                if str(row[13]) == 'None' or int(row[13]) < 1 or int(row[13]) > 14:
                    arcpy.AddError('Error: ' + table + ' - Valid Implementing Party is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Valid Implementing Party is required ', None, '', 'No'))
                    errorcount = errorcount + 1

                # Ensure a valid Office is selected
                if str(row[14]) == 'None' or int(row[14]) < 45 or int(row[14]) > 146:
                    arcpy.AddError('Error: ' + table + ' - Valid Office is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Valid Office is required', None, '', 'No'))
                    errorcount = errorcount + 1

                #Check to ensure a created by user is entered
                if str(row[15]) == 'None' or str(row[15]) == "":
                    arcpy.AddError('Error: ' + table + ' - Created By is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Created By is required', None, '', 'No'))
                    errorcount = errorcount + 1

                # Ensure an effectiveness status is selected
                if str(row[27]) == 'None' or int(row[27]) < 1 or int(row[27]) > 3:
                    arcpy.AddError('Error: ' + table + ' - Valid Effectiveness Status is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Valid Effectiveness Status is required', None, '', 'No'))
                    errorcount = errorcount + 1
                else:
                    #Check for Subactivites that have to be 3 or more years out to be successful
                    if int(row[27]) == 1:
                        enddateval = str(row[9])
                        endyear = str(enddateval)[0:4]
                        yeardif = int(curyear) - int(endyear)

                        if (int(row[5]) == 33 or int(row[5]) == 35 or int(row[5]) == 30 or int(row[5]) == 38 or int(row[5]) == 39 or int(row[5]) == 37 or int(row[5]) == 24 or int(row[5]) == 25 or int(row[5]) == 28 or int(row[5]) == 29) and yeardif < 3:
                            arcpy.AddError('Error: ' + table + ' - Effectiveness Status of "Effort is already effective" is not valid for this SubActivity unless 3 years have passed since the treatment ended. Please select "Effort has a high likelihood of being effective given adequate time" for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectiveness Status of "Effort is already effective" is not valid for this SubActivity unless 3 years have passed since the treatment ended. Please select "Effort has a high likelihood of being effective given adequate time".', None, '', 'No'))
                            errorcount = errorcount + 1

                # Ensure counts of documents, collaborators, land owners, and threats are valid
                if str(row[16]) == 'None' or int(row[16]) < 1:
                    arcpy.AddWarning('Warning: ' + table + ' - You indicated 0 documents for ObjectID: ' + str(row[0]) + '. Please ensure this is correct.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Warning', 'You indicated 0 documents. Please ensure this is correct.', None, '', 'No'))
                    warningcount = warningcount + 1

                if str(row[17]) == 'None' or int(row[17]) < 1:
                    arcpy.AddError('Warning: ' + table + ' - You indicated 0 collaborators for ObjectID: ' + str(row[0]) + '. If no collaborators exists, select "None".')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 collaborators. If no collaborators exists, select "None".', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[18]) == 'None' or int(row[18]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 land owners for ObjectID: ' + str(row[0]) + '. This is not possible, please indicate the correct number of land owers.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 land owners. This is not possible, please indicate the correct number of land owners.', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[19]) == 'None' or int(row[19]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 threats addressed for ObjectID: ' + str(row[0]) + '. This is not possible, please indicate the correct number of threats addressed.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 threats addressed. This is not possible, please indicate the correct number of threats addressed.', None, '', 'No'))
                    errorcount = errorcount + 1

                # Ensure counts of objectives, methods, and effectiveness statements are valid
                if str(row[24]) == 'None' or int(row[24]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 objectives for ObjectID: ' + str(row[0]) + '. You need at least 1 objective, please indicate the correct number of objectives.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 objectives. You need at least 1 objective, please indicate the correct number of objectives.', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[25]) == 'None' or int(row[25]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 methods for ObjectID: ' + str(row[0]) + '. You need at least 1 method, please indicate the correct number of methods.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 methods. You need at least 1 method, please indicate the correct number of methods.', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[26]) == 'None' or int(row[26]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 effectiveness statements for ObjectID: ' + str(row[0]) + '. You need at least 1 statement, please indicate the correct number of statements.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 statements. You need at least 1 statement, please indicate the correct number of statements.', None, '', 'No'))
                    errorcount = errorcount + 1









            # Check CED_1_Child_Table_Implementation_PECE_Questions
            if table == 'CED_1_Child_Table_Implementation_PECE_Questions':
                if str(row[1]) == 'None' or int(row[1]) < 1:
                    arcpy.AddError('Error: ' + table + ' - Spatial Effort Parent Table Project ID is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Spatial Effort Parent Table Project ID is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[2]) == '' or str(row[2]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Spatial Effort Parent Table Project Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Spatial Effort Parent Table Project Name is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[3]) == 'None' or (str(row[3]) != "Yes" and str(row[3]) != "No"):
                    arcpy.AddError('Error: ' + table + ' - PECE implementation question "High level certainty: Activity will be implemented" is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'PECE implementation "High level certainty: Activity will be implemented" is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[4]) == 'None' or (str(row[4]) != "Yes" and str(row[4]) != "No"):
                    arcpy.AddError('Error: ' + table + ' - PECE implementation question "High level certainty: Legal authority to conduct the activity" is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'PECE implementation "High level certainty: Legal authority to conduct the activity" is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[5]) == 'None' or (str(row[5]) != "Yes" and str(row[5]) != "No"):
                    arcpy.AddError('Error: ' + table + ' - PECE implementation question "High level certainty: Have resources necessary to carry out activity" is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'PECE implementation "High level certainty: Have resources necessary to carry out activity" is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[6]) == 'None' or (str(row[6]) != "Yes" and str(row[6]) != "No"):
                    arcpy.AddError('Error: ' + table + ' - PECE implementation question "High level certainty: Regulatory and procedural mechanisms in place" is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'PECE implementation "High level certainty: Regulatory and procedural mechanisms in place" is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[7]) == 'None' or (str(row[7]) != "Yes" and str(row[7]) != "No"):
                    arcpy.AddError('Error: ' + table + ' - PECE implementation question "High level certainty: Project requirements are met" is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'PECE implementation "High level certainty: Project requirements are met" is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[8]) == 'None' or (str(row[8]) != "Yes" and str(row[8]) != "No" and str(row[8]) != "NA"):
                    arcpy.AddError('Error: ' + table + ' - PECE implementation question "High level certainty: Adequate levels of voluntary participation (if applicable)" is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'PECE implementation "High level certainty: Adequate levels of voluntary participation (if applicable)" is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1


            # Check CED_1_Child_Table_Effectiveness_PECE_Questions
            if table == 'CED_1_Child_Table_Effectiveness_PECE_Questions':
                if str(row[1]) == 'None' or int(row[1]) < 1:
                    arcpy.AddError('Error: ' + table + ' - Parent Table Effort ID is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Parent Table Effort ID is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[2]) == '' or str(row[2]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Joining Project Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Joining Project Name is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[3]) == 'None' or (str(row[3]) != "Yes" and str(row[3]) != "No"):
                    arcpy.AddError('Error: ' + table + ' - PECE effectiveness question "Does Effort: Describe threat reduction" is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'PECE effectivenessquestion "Does Effort: Describe threat reduction" is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[4]) == 'None' or (str(row[4]) != "Yes" and str(row[4]) != "No"):
                    arcpy.AddError('Error: ' + table + ' - PECE effectivenessquestion "Does Effort: Provide Incremental Objectives" is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'PECE effectivenessquestion "Does Effort: Provide Incremental Objectives" is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[5]) == 'None' or (str(row[5]) != "Yes" and str(row[5]) != "No"):
                    arcpy.AddError('Error: ' + table + ' - PECE effectivenessquestion "Does Effort: Provide quantifiable performance measures for monitoring" is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'PECE effectivenessquestion "Does Effort: Provide quantifiable performance measures for monitoring" is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[6]) == 'None' or (str(row[6]) != "Yes" and str(row[6]) != "No"):
                    arcpy.AddError('Error: ' + table + ' - PECE effectivenessquestion "Does Effort: Incorporate principles of adaptive management" is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'PECE effectivenessquestion "Does Effort: Incorporate principles of adaptive management" is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                

            # Check for activity and sub activity specific for non-spatial efforts
            if table == 'CED_2_Batch_Template_NonSpatial_Projects':
                # Determine appropriate activity exists

                if str(row[4]) == 'None' or int(row[3]) < 4 or int(row[3]) > 8:
                    arcpy.AddError('Error: ' + table + ' - NonSpatial Activity is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'NonSpatial Activity is required', None, '', 'No'))
                    errorcount = errorcount + 1

                # Ensure mitigation status exists
                arcpy.AddError(str(row[25]))
                if str(row[25]) == 'None':
                    print(row[25])
                    arcpy.AddError('Error: ' + table + ' - Mitigation status is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Mitigation status is required', None, '', 'No'))
                    errorcount = errorcount + 1


                # Determine whether type of powerline answer is required and missing
                if int(row[4]) == 21:
                    if str(row[5]) != 'Distribution' and str(row[5]) != 'Transmission':
                        arcpy.AddError('Error: ' + table + ' - A powerline type is required for ObjectID: ' + str(row[0]) + ' with a Powerline Burial SubActivity')
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'A powerline type is required with a Powerline Burial SubActivity', None, '', 'No'))
                        errorcount = errorcount + 1


                # Ensure dates exist and start date occurs before end date
                if str(row[6]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Start Date is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Start Date is required', None, '', 'No'))
                    errorcount = errorcount + 1

                if  str(row[7]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - End Date is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'End Date is required', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[6]) != 'None' and str(row[7]) != 'None'and row[6] > row[7]:
                    arcpy.AddError('Error: ' + table + ' - End Date cannot occur before Start Date for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'End Date cannot occur before Start Date', None, '', 'No'))
                    errorcount = errorcount + 1

                #Check metric, metric value, GIS acres, and ensure GIS acres and metric value are close to each other
                if str(row[8]) == 'None' or str(row[8]) == "":
                    arcpy.AddError('Error: ' + table + ' - Metric Type is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Metric Type is required', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[9]) == 'None' or int(row[9]) <= 0:
                    arcpy.AddError('Error: ' + table + ' - Metric Value is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Metric Value is required', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[10]) == 'None' or int(row[10]) <= 0:
                    arcpy.AddError('Error: ' + table + ' - State is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'State is required', None, '', 'No'))
                    errorcount = errorcount + 1


                # Ensure a valid Implementing Party is selected
                if str(row[11]) == 'None' or int(row[11]) < 1 or int(row[11]) > 14:
                    arcpy.AddError('Error: ' + table + ' - Valid Implementing Party is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Valid Implementing Party is required ', None, '', 'No'))
                    errorcount = errorcount + 1

                # Ensure a valid Office is selected
                if str(row[12]) == 'None' or int(row[12]) < 45 or int(row[12]) > 146:
                    arcpy.AddError('Error: ' + table + ' - Valid Office is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Valid Office is required', None, '', 'No'))
                    errorcount = errorcount + 1

                #Check to ensure a created by user is entered
                if str(row[13]) == 'None' or str(row[13]) == "":
                    arcpy.AddError('Error: ' + table + ' - Created By is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Created By is required', None, '', 'No'))
                    errorcount = errorcount + 1

                # Ensure counts of documents, collaborators, land owners, and threats are valid
                if str(row[14]) == 'None' or int(row[14]) < 1:
                    arcpy.AddWarning('Warning: ' + table + ' - You indicated 0 documents for ObjectID: ' + str(row[0]) + '. Please ensure this is correct.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Warning', 'You indicated 0 documents. Please ensure this is correct.', None, '', 'No'))
                    warningcount = warningcount + 1

                if str(row[15]) == 'None' or int(row[15]) < 1:
                    arcpy.AddError('Warning: ' + table + ' - You indicated 0 collaborators for ObjectID: ' + str(row[0]) + '. If no collaborators exists, select "None".')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 collaborators. If no collaborators exists, select "None".', None, '', 'No'))
                    warningcount = warningcount + 1

                if str(row[16]) == 'None' or int(row[16]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 land owners for ObjectID: ' + str(row[0]) + '. This is not possible, please indicate the correct number of land owers.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 land owners. This is not possible, please indicate the correct number of land owers.', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[17]) == 'None' or int(row[17]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 threats addressed for ObjectID: ' + str(row[0]) + '. This is not possible, please indicate the correct number of threats addressed.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 threats addressed. This is not possible, please indicate the correct number of threats addressed.', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[18]) == 'None' or int(row[18]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 counties impacted for ObjectID: ' + str(row[0]) + '. This is not possible, please indicate the correct number of counties impacted.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 counties impacted. This is not possible, please indicate the correct number of counties impacted.', None, '', 'No'))
                    errorcount = errorcount + 1

                # Ensure counts of objectives, methods, and effectiveness statements are valid
                if str(row[21]) == 'None' or int(row[21]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 objectives for ObjectID: ' + str(row[0]) + '. You need at least 1 objective, please indicate the correct number of objectives.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 objectives. You need at least 1 objective, please indicate the correct number of objectives.', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[22]) == 'None' or int(row[22]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 methods for ObjectID: ' + str(row[0]) + '. You need at least 1 method, please indicate the correct number of methods.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 methods. You need at least 1 method, please indicate the correct number of methods.', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[23]) == 'None' or int(row[23]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 effectiveness statements for ObjectID: ' + str(row[0]) + '. You need at least 1 statement, please indicate the correct number of statements.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 statements. You need at least 1 statement, please indicate the correct number of statements.', None, '', 'No'))
                    errorcount = errorcount + 1


            

            # Check for activity and sub activity specific for non-spatial plans
            if table == 'CED_3_Batch_Template_NonSpatial_Plans':
                # Determine appropriate activity exists


                if str(row[4]) == 'None' or int(row[3]) < 2 or int(row[3]) > 3:
                    arcpy.AddError('Error: ' + table + ' - NonSpatial Plan is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'NonSpatial Plan is required', None, '', 'No'))
                    errorcount = errorcount + 1

                # Ensure mitigation status exists
                arcpy.AddError(str(row[18]))
                if str(row[18]) == 'None':
                    print(row[18])
                    arcpy.AddError('Error: ' + table + ' - Mitigation status is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Mitigation status is required', None, '', 'No'))
                    errorcount = errorcount + 1

                
                #Check metric, metric value, GIS acres, and ensure GIS acres and metric value are close to each other
                if str(row[5]) == 'None' or str(row[5]) == "":
                    arcpy.AddError('Error: ' + table + ' - Metric Type is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Metric Type is required', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[6]) == 'None' or int(row[6]) <= 0:
                    arcpy.AddError('Error: ' + table + ' - Metric Value is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Metric Value is required', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[7]) == 'None' or int(row[7]) <= 0:
                    arcpy.AddError('Error: ' + table + ' - State is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'State is required', None, '', 'No'))
                    errorcount = errorcount + 1


                # Ensure a valid Implementing Party is selected
                if str(row[8]) == 'None' or int(row[8]) < 1 or int(row[8]) > 14:
                    arcpy.AddError('Error: ' + table + ' - Valid Implementing Party is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Valid Implementing Party is required ', None, '', 'No'))
                    errorcount = errorcount + 1

                # Ensure a valid Office is selected
                if str(row[9]) == 'None' or int(row[9]) < 45 or int(row[9]) > 146:
                    arcpy.AddError('Error: ' + table + ' - Valid Office is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Valid Office is required', None, '', 'No'))
                    errorcount = errorcount + 1

                #Check to ensure a created by user is entered
                if str(row[10]) == 'None' or str(row[10]) == "":
                    arcpy.AddError('Error: ' + table + ' - Created By is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Created By is required', None, '', 'No'))
                    errorcount = errorcount + 1


                # Ensure counts of documents, collaborators, land owners, and threats are valid
                if str(row[11]) == 'None' or int(row[11]) < 1:
                    arcpy.AddWarning('Warning: ' + table + ' - You indicated 0 documents for ObjectID: ' + str(row[0]) + '. Please ensure this is correct.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Warning', 'You indicated 0 documents. Please ensure this is correct.', None, '', 'No'))
                    warningcount = warningcount + 1

                if str(row[12]) == 'None' or int(row[12]) < 1:
                    arcpy.AddError('Warning: ' + table + ' - You indicated 0 collaborators for ObjectID: ' + str(row[0]) + '. Please ensure this is correct.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Warning', 'You indicated 0 collaborators. Please ensure this is correct.', None, '', 'No'))
                    warningcount = warningcount + 1

                if str(row[13]) == 'None' or int(row[13]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 land owners for ObjectID: ' + str(row[0]) + '. This is not possible, please indicate the correct number of land owers.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 land owners. This is not possible, please indicate the correct number of land owers.', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[14]) == 'None' or int(row[14]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 threats addressed for ObjectID: ' + str(row[0]) + '. This is not possible, please indicate the correct number of threats addressed.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 threats addressed. This is not possible, please indicate the correct number of threats addressed.', None, '', 'No'))
                    errorcount = errorcount + 1

                if str(row[15]) == 'None' or int(row[15]) < 1:
                    arcpy.AddError('Error: ' + table + ' - You indicated 0 counties impacted for ObjectID: ' + str(row[0]) + '. This is not possible, please indicate the correct number of counties impacted.')
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'You indicated 0 counties impacted. This is not possible, please indicate the correct number of counties impacted.', None, '', 'No'))
                    errorcount = errorcount + 1

                
            # Check collaborators, documents, land owners, and threats for spatial, non-spatial, and plan tables

            # Check all collaborators
            if table == 'CED_1_Child_Table_Spatial_Project_Collaborators' or table == 'CED_2_Child_Table_NonSpatial_Project_Collaborators' or table == 'CED_3_Child_Table_NonSpatial_Plan_Collaborators':
                if str(row[1]) == 'None' or int(row[1]) < 1:
                    arcpy.AddError('Error: ' + table + ' - Collaborator Parent Table Effort ID is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Collaborator Parent Table Effort ID is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[2]) == '' or str(row[2]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Collaborator Project Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Collaborator Project Name is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[3]) == 'None' or (int(row[3]) < 1 or int(row[3])) > 14:
                    arcpy.AddError('Error: ' + table + ' - Collaborator is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Collaborator is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1


            # Check all documentation
            if table == 'CED_1_Child_Table_Spatial_Project_Documentation' or table == 'CED_2_Child_Table_NonSpatial_Project_Documentation' or table == 'CED_3_Child_Table_NonSpatial_Plan_Documentation':
                if str(row[1]) == 'None' or int(row[1]) < 1:
                    arcpy.AddError('Error: ' + table + ' - Document Parent Table Effort ID is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Document Parent Table Effort ID is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[2]) == '' or str(row[2]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Document Project Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Document Project Name is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[3]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Document Type is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Document Type is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[4]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Document Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Document Name is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if table == 'CED_1_Child_Table_Spatial_Project_Documentation':
                    doctable = 'CED_1_Child_Table_Spatial_Project_Documentation__ATTACH'


                if table == 'CED_2_Child_Table_NonSpatial_Project_Documentation':
                    doctable = 'CED_2_Child_Table_NonSpatial_Project_Documentation__ATTACH'


                if table == 'CED_3_Child_Table_NonSpatial_Plan_Documentation':
                    doctable = 'CED_3_Child_Table_NonSpatial_Plan_Documentation__ATTACH'

                pdocgblid = str(row[6])
                docfields = ['REL_GLOBALID']
                docattached = 0
                try:
                    del doccursor
                except:
                    a = 1
                with arcpy.da.SearchCursor(doctable, docfields) as doccursor: # Search through all records in the table
                    for docrow in doccursor: # Loop through each record
                        if str(pdocgblid) == str(docrow[0]):
                            docattached = 1

                    if docattached == 0:
                        arcpy.AddError('Error: ' + table + ' - No document attached for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'No document attached', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1

                del doccursor
            # Check all land owners
            if table == 'CED_1_Child_Table_Spatial_Project_Land_Owners' or table == 'CED_2_Child_Table_NonSpatial_Project_Land_Owners' or table == 'CED_3_Child_Table_NonSpatial_Plan_Land_Owners':
                if str(row[1]) == 'None' or int(row[1]) < 1:
                    arcpy.AddError('Error: ' + table + ' - Land Owner Parent Table Effort ID is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Land Owner Parent Table Effort ID is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[2]) == '' or str(row[2]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Land Owner Project Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Land Owner Project Name is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[3]) == 'None' or int(row[3]) < 1 or (int(row[3])) > 14:
                    arcpy.AddError('Error: ' + table + ' - Land Owner is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Land Owner Type is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1


            # Check all threats
            if table == 'CED_1_Child_Table_Spatial_Project_Threats' or table == 'CED_2_Child_Table_NonSpatial_Project_Threats' or table == 'CED_3_Child_Table_NonSpatial_Plan_Threats':
                if str(row[1]) == 'None' or int(row[1]) < 1:
                    arcpy.AddError('Error: ' + table + ' - Threat Parent Table Effort ID is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Threat Parent Table Effort ID is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[2]) == '' or str(row[2]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Threat Project Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Threat Project Name is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[3]) == 'None' or (int(row[3]) < 1 or int(row[3])) > 13:
                    arcpy.AddError('Error: ' + table + ' - Threat is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Threat Type is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1


            # Check all counties
            if table == 'CED_2_Child_Table_NonSpatial_Project_Counties' or table == 'CED_3_Child_Table_NonSpatial_Plan_Counties':
                if str(row[1]) == 'None' or int(row[1]) < 1:
                    arcpy.AddError('Error: ' + table + ' - County Parent Table Effort ID is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'County Parent Table Effort ID is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[2]) == '' or str(row[2]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - County Project Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'County Project Name is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[3]) == 'None' or (int(row[3]) < 65535 or int(row[3])) > 65777:
                    arcpy.AddError('Error: ' + table + ' - County is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'County Type is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

            # Check all objectives
            if table == 'CED_1_Child_Table_Spatial_Project_Objectives' or table == 'CED_2_Child_Table_NonSpatial_Project_Objectives':
                if str(row[1]) == 'None' or int(row[1]) < 1:
                    arcpy.AddError('Error: ' + table + ' - Objective Parent Table Effort ID is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective Parent Table Effort ID is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[2]) == '' or str(row[2]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Objective Project Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective Project Name is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                #Check Annual Grass objectives
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '30':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '49' or str(row[4]) == '50' or str(row[4]) == '51' or str(row[4]) == '52' or str(row[4]) == '53' or str(row[4]) == '54': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Area Closure objectives
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '31':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '71' or str(row[4]) == '72' or str(row[4]) == '73': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Conifer Removal objectives
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '17':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '32' or str(row[4]) == '33' or str(row[4]) == '34' or str(row[4]) == '35' or str(row[4]) == '36' or str(row[4]) == '37' or str(row[4]) == '38' or str(row[4]) == '39' or str(row[4]) == '40': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Conservation Easement objectives
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '34':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '1' or str(row[4]) == '6' or str(row[4]) == '7' or str(row[4]) == '8' or str(row[4]) == '9': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Oil and Gas Energy objectives
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '37':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '66' or str(row[4]) == '67' or str(row[4]) == '68' or str(row[4]) == '69' or str(row[4]) == '70': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Fence Modification objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '19':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '92' or str(row[4]) == '93': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Fence Marking objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '18':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '90' or str(row[4]) == '91': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Fence Removal objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '20':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '94' or str(row[4]) == '95': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Fuel Break objectives
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '35':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '28' or str(row[4]) == '29' or str(row[4]) == '30' or str(row[4]) == '31': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1


                #Check Fuels Management objectives
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '32':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '46' or str(row[4]) == '47' or str(row[4]) == '48': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Improved Grazing objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '24':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '74' or str(row[4]) == '75' or str(row[4]) == '76' or str(row[4]) == '77' or str(row[4]) == '78': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Land Acquisition objectives
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '36':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '21' or str(row[4]) == '22' or str(row[4]) == '23' or str(row[4]) == '24' or str(row[4]) == '25' or str(row[4]) == '26' or str(row[4]) == '27': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Noxious Weeds objectives
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '38':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '55' or str(row[4]) == '56' or str(row[4]) == '57' or str(row[4]) == '58': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1


                #Check Powerline Burial objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '21':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '85' or str(row[4]) == '86' or str(row[4]) == '87': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Powerline Modification objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '22':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '83' or str(row[4]) == '84': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1


                #Check Road Trail Closure objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '27':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '79' or str(row[4]) == '80': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1


                #Check Road Trail Route objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '26':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '81' or str(row[4]) == '82': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1


                #Check Riparean objectives
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '39':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '59' or str(row[4]) == '60' or str(row[4]) == '61' or str(row[4]) == '62' or str(row[4]) == '63' or str(row[4]) == '64' or str(row[4]) == '65': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Structure Removal objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '23':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '88' or str(row[4]) == '89': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Translocation objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '25':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '100' or str(row[4]) == '101' or str(row[4]) == '102': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Veg management/habatat enhancement objectives
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '33':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '41' or str(row[4]) == '42' or str(row[4]) == '43' or str(row[4]) == '44' or str(row[4]) == '45': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Wild Equid Gather objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '28':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '98' or str(row[4]) == '99': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Wild equid population control objectives
                if table == 'CED_2_Child_Table_NonSpatial_Project_Objectives' and str(row[3]) == '29':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Objective Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Objective Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '96' or str(row[4]) == '97': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Objective listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Objective listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1





            # Check all methods
            if table == 'CED_1_Child_Table_Spatial_Project_Methods' or table == 'CED_2_Child_Table_NonSpatial_Project_Methods':
                if str(row[1]) == 'None' or int(row[1]) < 1:
                    arcpy.AddError('Error: ' + table + ' - Method Parent Table Effort ID is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Parent Table Effort ID is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[2]) == '' or str(row[2]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Method Project Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Name is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                #Check Annual Grass Methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '30':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '217' or str(row[4]) == '218' or str(row[4]) == '219' or str(row[4]) == '220' or str(row[4]) == '221' or str(row[4]) == '222' or str(row[4]) == '281': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Area Closure Methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '31':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '239' or str(row[4]) == '240' or str(row[4]) == '241' or str(row[4]) == '292' or str(row[4]) == '293' or str(row[4]) == '297' or str(row[4]) == '295' or str(row[4]) == '296': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Conifer Removal Methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '17':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '208' or str(row[4]) == '266' or str(row[4]) == '267' or str(row[4]) == '268' or str(row[4]) == '269' or str(row[4]) == '270' or str(row[4]) == '271' or str(row[4]) == '272': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Conservation Easement Methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '34':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '203' or str(row[4]) == '204' or str(row[4]) == '262' or str(row[4]) == '309': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Oil and Gas Energy Methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '37':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '286' or str(row[4]) == '287' or str(row[4]) == '288' or str(row[4]) == '289' or str(row[4]) == '290' or str(row[4]) == '291': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Fence Modification Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '19':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '255' or str(row[4]) == '256' or str(row[4]) == '304' or str(row[4]) == '305': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Fence Marking Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '18':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '254': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Fence Removal Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '20':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '257': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Fuel Break Methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '35':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '206' or str(row[4]) == '207' or str(row[4]) == '263' or str(row[4]) == '264' or str(row[4]) == '265': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1


                #Check Fuels Management Methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '32':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '214' or str(row[4]) == '215' or str(row[4]) == '216' or str(row[4]) == '277' or str(row[4]) == '278' or str(row[4]) == '279' or str(row[4]) == '280': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Improved Grazing Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '24':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '242' or str(row[4]) == '243' or str(row[4]) == '244' or str(row[4]) == '245' or str(row[4]) == '246' or str(row[4]) == '297' or str(row[4]) == '298': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Land Acquisition Methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '36':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '205': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Noxious Weeds Methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '38':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '223' or str(row[4]) == '224' or str(row[4]) == '225' or str(row[4]) == '226' or str(row[4]) == '282' or str(row[4]) == '283' or str(row[4]) == '284': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1


                #Check Powerline Burial Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '21':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '252': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Powerline Modification Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '22':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '250' or str(row[4]) == '251' or str(row[4]) == '302' or str(row[4]) == '303': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1


                #Check Road Trail Closure Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '27':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '247' or str(row[4]) == '249' or str(row[4]) == '299' or str(row[4]) == '300' or str(row[4]) == '301': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1


                #Check Road Trail Route Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '26':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '249': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1


                #Check Riparean Methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '39':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '227' or str(row[4]) == '228' or str(row[4]) == '229' or str(row[4]) == '230' or str(row[4]) == '231' or str(row[4]) == '232' or str(row[4]) == '233' or str(row[4]) == '234' or str(row[4]) == '235' or str(row[4]) == '236' or str(row[4]) == '237' or str(row[4]) == '238' or str(row[4]) == '285': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Structure Removal Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '23':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '253': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Translocation Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '25':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '261': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Veg management/habatat enhancement Methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '33':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '209' or str(row[4]) == '210' or str(row[4]) == '211' or str(row[4]) == '212' or str(row[4]) == '213' or str(row[4]) == '273' or str(row[4]) == '274' or str(row[4]) == '275' or str(row[4]) == '276': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Wild Equid Gather Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '28':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '260': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Wild equid population control Methods
                if table == 'CED_2_Child_Table_NonSpatial_Project_Methods' and str(row[3]) == '29':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Method Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Method Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if str(row[4]) == '258' or str(row[4]) == '259' or str(row[4]) == '306': 
                            a = 1
                        else:
                            arcpy.AddError('Error: ' + table + ' - Method listed is incorrect for the specified SubActivity for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method listed is incorrect for the specified SubActivity.', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1



                #Check Annual Grass methods check
                if table == 'CED_1_Child_Table_Spatial_Project_Objectives' and str(row[3]) == '30':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful
                            if str(row[4]) == '115' or str(row[4]) == '118': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '116' or str(row[4]) == '118': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '117' or str(row[4]) == '118': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1






                #Check Vegetation / Habitat enhancement objectives against the selected methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '33':
                    objtable = 'CED_1_Child_Table_Spatial_Project_Objectives'
                    objfields = ['OBJECTID', 'PrjID', 'PrjName', 'SubActivity', 'Objective', 'ParentGlobalID', 'GlobalID']
                    expression = "PrjID = " + str(row[1])
                    objlist = []
                    with arcpy.da.SearchCursor(objtable, objfields, where_clause=expression) as objcursor:
                        for objrow in objcursor:
                            objlist.append(objrow[4])
                        del objrow
                    del objcursor
                    if str(row[4]) == '209' or str(row[4]) == '210' or str(row[4]) == '211' or str(row[4]) == '212' or str(row[4]) == '213' or str(row[4]) == '276':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 41 or objitem == 42 or objitem == 43:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1
                    if str(row[4]) == '273' or str(row[4]) == '274' or str(row[4]) == '275' or str(row[4]) == '213' or str(row[4]) == '276':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 44:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Fuels Mangement enhancement objectives against the selected methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '32':
                    objtable = 'CED_1_Child_Table_Spatial_Project_Objectives'
                    objfields = ['OBJECTID', 'PrjID', 'PrjName', 'SubActivity', 'Objective', 'ParentGlobalID', 'GlobalID']
                    expression = "PrjID = " + str(row[1])
                    objlist = []
                    with arcpy.da.SearchCursor(objtable, objfields, where_clause=expression) as objcursor:
                        for objrow in objcursor:
                            objlist.append(objrow[4])
                        del objrow
                    del objcursor
                    if str(row[4]) == '214' or str(row[4]) == '215' or str(row[4]) == '216':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 46 or objitem == 48:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1
                    if str(row[4]) == '277' or str(row[4]) == '278':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 47 or objitem == 48:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                #Check Riparean objectives against the selected methods
                if table == 'CED_1_Child_Table_Spatial_Project_Methods' and str(row[3]) == '39':
                    objtable = 'CED_1_Child_Table_Spatial_Project_Objectives'
                    objfields = ['OBJECTID', 'PrjID', 'PrjName', 'SubActivity', 'Objective', 'ParentGlobalID', 'GlobalID']
                    expression = "PrjID = " + str(row[1])
                    objlist = []
                    with arcpy.da.SearchCursor(objtable, objfields, where_clause=expression) as objcursor:
                        for objrow in objcursor:
                            objlist.append(objrow[4])
                        del objrow
                    del objcursor
                    if str(row[4]) == '227':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 59 or objitem == 60 or objitem == 62:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                    if str(row[4]) == '228':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 59 or objitem == 60:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                    if str(row[4]) == '229':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 59 or objitem == 60:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                    if str(row[4]) == '230':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 59:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                    if str(row[4]) == '231':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 59:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                    if str(row[4]) == '233':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 61 or objitem == 62 or objitem == 63:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                    if str(row[4]) == '234':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 61 or objitem == 62 or objitem == 63:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                    if str(row[4]) == '235':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 61 or objitem == 62 or objitem == 63:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                    if str(row[4]) == '236':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 61 or objitem == 62 or objitem == 63:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                    if str(row[4]) == '237':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 62:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

                    if str(row[4]) == '238':
                        objaccept = 0
                        for objitem in objlist:
                            if objitem == 64:
                                objaccept = 1
                        if objaccept == 0:
                            arcpy.AddError('Error: ' + table + ' - Method type is incorrect for specified objectives for ObjectID: ' + str(row[0]))
                            cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Method Type is incorrect for specified objectives. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                            errorcount = errorcount + 1

            # Check all effectiveness statements
            if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' or table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements':
                if str(row[1]) == 'None' or int(row[1]) < 1:
                    arcpy.AddError('Error: ' + table + ' - Effectiveness Statement Parent Table Effort ID is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectiveness Statement Parent Table Effort ID is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[2]) == '' or str(row[2]) == 'None':
                    arcpy.AddError('Error: ' + table + ' - Effectiveness Statement Project Name is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectiveness Statement Name is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1

                if str(row[4]) == 'None' or int(row[4]) < 1:
                    arcpy.AddError('Error: ' + table + ' - Effectiveness Statement is required for ObjectID: ' + str(row[0]))
                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectiveness Statement is required', str(pobjid), str(pgblid), 'No'))
                    errorcount = errorcount + 1


                #Check annual grass effectiveness statement check
                if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' and str(row[3]) == '38':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor
                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '46' or str(row[4]) == '47' or str(row[4]) == '55': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '48' or str(row[4]) == '49' or str(row[4]) == '50' or str(row[4]) == '51' or str(row[4]) == '55': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '52' or str(row[4]) == '53' or str(row[4]) == '54' or str(row[4]) == '55': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check area closure effectiveness statement check
                if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' and str(row[3]) == '31':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor
                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '83' or str(row[4]) == '87': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '84' or str(row[4]) == '85' or str(row[4]) == '87': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '86' or str(row[4]) == '87': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1


                #Check connifer removal effectiveness statement check
                if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' and str(row[3]) == '17':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor

                    objectivetable = 'CED_1_Child_Table_Spatial_Project_Objectives'
                    objfields = ['OBJECTID', 'PrjID', 'Objective']
                    objexpression = "PrjID = " + str(row[1])
                    objlist = []
                    with arcpy.da.SearchCursor(objectivetable, objfields, where_clause=objexpression) as objcursor:
                        for objrow in objcursor:
                            objlist.append(objrow[2])
                        del objrow
                    del objcursor

                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)


                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '17' or str(row[4]) == '25' or str(row[4]) == '16': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 1 and yeardif < 3: # Successful, 3 or more years since treatment completion has not been achieved 
                            if str(row[4]) == '17' or str(row[4]) == '25': 
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Not enough time has passed to select this "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Not enough time has passed to select this "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1
                            if str(row[4]) == '18' or str(row[4]) == '19' or str(row[4]) == '20' or str(row[4]) == '21' or str(row[4]) == '22' or str(row[4]) == '23' or str(row[4]) == '24': 
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 1: # Successful with the proper objective
                            if str(row[4]) == '16':
                                goodobj = 0
                                for obj in objlist:
                                    if obj == 34 or obj == 35:
                                        goodobj = 1
                                if goodobj == 1:
                                    a = 1
                                else:
                                    arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. This "Successful" effectiveness statement is only applicable for Objectives 3 and 4 in Conifer Removal if the time frame is less than 3 years')
                                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. This "Successful" effectiveness statement is only applicable for Objectives 3 and 4 in Conifer Removal if the time frame is less than 3 years', str(pobjid), str(pgblid), 'No'))
                                    errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '18' or str(row[4]) == '19' or str(row[4]) == '20' or str(row[4]) == '21' or str(row[4]) == '22' or str(row[4]) == '25': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '23' or str(row[4]) == '24' or str(row[4]) == '25': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Conservation Easement effectiveness statement check
                if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' and str(row[3]) == '34':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '1' or str(row[4]) == '4': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '2' or str(row[4]) == '4': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '3' or str(row[4]) == '4': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1


                #Check energy oil and gas effectiveness statement check
                if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' and str(row[3]) == '37':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor
                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '74' or str(row[4]) == '75' or str(row[4]) == '82': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '76' or str(row[4]) == '77' or str(row[4]) == '78' or str(row[4]) == '79' or str(row[4]) == '82': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '80' or str(row[4]) == '81' or str(row[4]) == '82': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Fence modification effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '19':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '124' or str(row[4]) == '127': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '125' or str(row[4]) == '127': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '126' or str(row[4]) == '127': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Fence Marking effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '18':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '119' or str(row[4]) == '123': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '120' or str(row[4]) == '123': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '121' or str(row[4]) == '122' or str(row[4]) == '123': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Fence Removal effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '20':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '128' or str(row[4]) == '131': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '129' or str(row[4]) == '131': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '130' or str(row[4]) == '131': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Fuel Break effectiveness statement check
                if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' and str(row[3]) == '35':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor
                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '9' or str(row[4]) == '15': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '10' or str(row[4]) == '11' or str(row[4]) == '12' or str(row[4]) == '15': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '13' or str(row[4]) == '14' or str(row[4]) == '15': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Fuels Management effectiveness statement check
                if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' and str(row[3]) == '32':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor

                    objectivetable = 'CED_1_Child_Table_Spatial_Project_Objectives'
                    objfields = ['OBJECTID', 'PrjID', 'Objective']
                    objexpression = "PrjID = " + str(row[1])
                    objlist = []
                    with arcpy.da.SearchCursor(objectivetable, objfields, where_clause=objexpression) as objcursor:
                        for objrow in objcursor:
                            objlist.append(objrow[2])
                            del objrow
                    del objcursor

                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)


                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '36' or str(row[4]) == '37' or str(row[4]) == '45': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 1 and yeardif < 3: # Successful, 3 or more years since treatment completion has not been achieved 
                            if str(row[4]) == '37' or str(row[4]) == '45': 
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Not enough time has passed to select this "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Not enough time has passed to select this "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1
                            if str(row[4]) == '38' or str(row[4]) == '39' or str(row[4]) == '40' or str(row[4]) == '41' or str(row[4]) == '42' or str(row[4]) == '43' or str(row[4]) == '44': 
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 1: # Successful with the proper objective
                            if str(row[4]) == '36':
                                goodobj = 0
                                for obj in objlist:
                                    if obj == 46:
                                        goodobj = 1
                                if goodobj == 1:
                                    a = 1
                                else:
                                    arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. This "Successful" effectiveness statement is only applicable for Objectives 3 and 4 in Conifer Removal if the time frame is less than 3 years')
                                    cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. This "Successful" effectiveness statement is only applicable for Objectives 3 and 4 in Conifer Removal if the time frame is less than 3 years', str(pobjid), str(pgblid), 'No'))
                                    errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '38' or str(row[4]) == '39' or str(row[4]) == '40' or str(row[4]) == '41' or str(row[4]) == '45': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '42' or str(row[4]) == '43' or str(row[4]) == '44' or str(row[4]) == '45': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Improved Grazing Practices effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '24':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor
                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '88' or str(row[4]) == '94': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '89' or str(row[4]) == '90' or str(row[4]) == '91' or str(row[4]) == '94': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '92' or str(row[4]) == '93' or str(row[4]) == '94': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Land Acquisition effectiveness statement check
                if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' and str(row[3]) == '36':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful
                            if str(row[4]) == '5' or str(row[4]) == '8': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '6' or str(row[4]) == '8': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '7' or str(row[4]) == '8': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1


                #Check Noxious Weeds effectiveness statement check
                if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' and str(row[3]) == '38':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor
                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '56' or str(row[4]) == '64': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '57' or str(row[4]) == '58' or str(row[4]) == '59' or str(row[4]) == '60' or str(row[4]) == '64': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '61' or str(row[4]) == '62' or str(row[4]) == '63' or str(row[4]) == '64': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Powerline Burial effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '21':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful
                            if str(row[4]) == '111' or str(row[4]) == '114': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '112' or str(row[4]) == '114': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '113' or str(row[4]) == '114': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Powerline Modification effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '22':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful
                            if str(row[4]) == '105' or str(row[4]) == '110': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '106' or str(row[4]) == '107' or str(row[4]) == '110': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '108' or str(row[4]) == '109' or str(row[4]) == '110': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Road or Trail Closure effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '27':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful
                            if str(row[4]) == '95' or str(row[4]) == '99': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '96' or str(row[4]) == '99': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '97' or str(row[4]) == '98' or str(row[4]) == '99': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Reroute Road or Trail effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '26':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful
                            if str(row[4]) == '100' or str(row[4]) == '104': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '101' or str(row[4]) == '104': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '102' or str(row[4]) == '103' or str(row[4]) == '104': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1


                #Check riparean effectiveness statement check
                if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' and str(row[3]) == '39':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor
                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '65' or str(row[4]) == '73': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '66' or str(row[4]) == '67' or str(row[4]) == '68' or str(row[4]) == '69' or str(row[4]) == '73': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '70' or str(row[4]) == '71' or str(row[4]) == '72' or str(row[4]) == '73': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1


                #Check Structure Removal effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '23':
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1: # Successful
                            if str(row[4]) == '115' or str(row[4]) == '118': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '116' or str(row[4]) == '118': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '117' or str(row[4]) == '118': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check Translocation effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '25':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor
                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '141' or str(row[4]) == '144': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '142' or str(row[4]) == '144': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '143' or str(row[4]) == '144': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check post disturbance or habitat enhancement effectiveness statement check
                if table == 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements' and str(row[3]) == '33':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor
                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '26' or str(row[4]) == '27' or str(row[4]) == '35': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '28' or str(row[4]) == '29' or str(row[4]) == '30' or str(row[4]) == '31' or str(row[4]) == '35': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '32' or str(row[4]) == '33' or str(row[4]) == '34' or str(row[4]) == '35': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check wild equid gather effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '28':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor
                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '137' or str(row[4]) == '140': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '138' or str(row[4]) == '140': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '139' or str(row[4]) == '140': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                #Check wild equid population control effectiveness statement check
                if table == 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements' and str(row[3]) == '29':
                    stattable = 'CED_1_Batch_Template_Spatial_Projects'
                    statfields = ['OBJECTID', 'Effect_Status', 'End_Date']
                    expression = "OBJECTID = " + str(row[1])
                    with arcpy.da.SearchCursor(stattable, statfields, where_clause=expression) as statcursor:
                        for statrow in statcursor:
                            statval = statrow[1]
                            enddateval = statrow[2]
                    del statcursor
                    endyear = str(enddateval)[0:4]
                    yeardif = int(curyear) - int(endyear)
                    if str(row[4]) == 'None' or int(row[4]) < 1:
                        arcpy.AddError('Error: ' + table + ' - Please specify an Effectivenss Statement for ObjectID: ' + str(row[0]))
                        cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Please specify an Effectivenss Statement', str(pobjid), str(pgblid), 'No'))
                        errorcount = errorcount + 1
                    else:
                        if statval == 1 and yeardif > 2: # Successful, 3 or more years since treatment completion
                            if str(row[4]) == '132' or str(row[4]) == '136': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Successful" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Successful" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 3: # Highly likely
                            if str(row[4]) == '132' or str(row[4]) == '134' or str(row[4]) == '136': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select a "Highly Likely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Highly Likely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1

                        if statval == 2: # Unlikely
                            if str(row[4]) == '135' or str(row[4]) == '136': 
                                a = 1
                            else:
                                arcpy.AddError('Error: ' + table + ' - Effectivness statement is incorrect for specified Effectiveness Status for ObjectID: ' + str(row[0]) + '. Please select an "Uncertain or Unlikely" effectiveness statement.')
                                cursorerror.insertRow((table, str(objid), str(gblid), str(prjnm), 'Error', 'Effectivness statement is incorrect for specified Effectiveness Status. Please select a "Uncertain or Unlikely" effectiveness statement. Consult data diagram for more information', str(pobjid), str(pgblid), 'No'))
                                errorcount = errorcount + 1
                    

                    


#Explain to the user the error 
if errorcount > 0 or warningcount > 0:
    arcpy.AddWarning("Error check complete. The error check identified " + str(errorcount) + " errors and " + str(warningcount) + " warnings. Ignore the 'Failed to Execute' error message below. Please be sure to address all issues in your CED_Error_Log table. You must re-run the error check when again once you have corrected all errors to ensure compliance with the CED. Due to errors existing in your batch upload, this tool will end with an automatic 'Failed to Execute' error message if any errors are encountered. The script ran successfully. Once you correct your errors and re-run the script, the error message will no longer appear if only warnings remain. Thank you.")
else:
    arcpy.AddMessage("Error check complete. No errors were found. If you add more data to the batch upload template, please re-run the error check.")


