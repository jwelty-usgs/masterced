##############################################################################################################################
# File Name: Create_All_Child_Records.py
# Author: Justin L. Welty
# Created: April 30th, 2018
# Last Modified: May 8th, 2018
# Python Modules Required: arcpy.
#Purpose: Create all necessary child records for CED efforts based specific fields within the parent tables. 
##############################################################################################################################

# Import the arcpy module or throw error if the module isn't found
try:
    import arcpy #Try to import acrpy
except: 
    arcpy.AddError('Error: arcpy module not found, process terminated') # Add an error message if import arcpy fails
    sys.exit() # Exit the script

# Set the geodatabase where the actions will take place.
gdb = arcpy.GetParameterAsText(0)

arcpy.AddMessage("This tool will loop through all parent and child subtables looking for missing or extra records based on the number of records you indicated are needed for each child table. If missing records exist new child records will be added to the appropriate table and a simple message in the results windo will tell you how many and where these records were created. If extra records are discovered for a particular effort, a warning message will appear asking you to delete them.")

###################################################################################################################################################
### Documentation
###################################################################################################################################################
# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberDocs', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']



for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Documentation'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Documentation'
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                outtable = 'CED_3_Child_Table_NonSpatial_Plan_Documentation'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of documnets to be created for the project
            except:
                totrec = int(0)

            gblid = str(row[3]) # Get the parent Global ID for the effort

            if totrec > 0:
                if arcpy.Exists("outtable_view"): # If the table view exists
                    arcpy.Delete_management("outtable_view") # Delete the table view

                arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
                arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
                result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
                existrec = int(result[0]) # Get the count of existing records as a variable
                newrec = totrec - existrec # Determine the number of new records that need to be created

                if newrec < 0:
                    extrarows = newrec * -1
                    arcpy.AddWarning("There are " + str(extrarows) + " extra document records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of document records for this effort. Please manually delete the document rows for this effort that not longer apply.")

                if arcpy.Exists("outtable_view"): # If the table view exists
                    arcpy.Delete_management("outtable_view") # Delete the table view

                if newrec > 0:
                    arcpy.AddMessage("New document records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " = " + str(newrec) + " records in " + outtable + ".")
                    temptable = gdb.replace('CED_2x_Batch_Template_23October2018.gdb','CED_2x_Batch_Template_23October2018_PythonScripts\CED_2x_Batch_Template_Temp_Files.gdb\Temporary_Documentation_Table')
                    cursor1 = arcpy.da.InsertCursor(temptable, outfields) #Set the Insert Cursor
                    for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                        
                        cursor1.insertRow((prjid, prjnm, gblid))

                    del cursor1 # Delete cursor1

                    arcpy.Append_management(temptable, outtable, "NO_TEST")

                    arcpy.DeleteRows_management(temptable)
                
    del cursor  # Delete cursor

###################################################################################################################################################
### Objectives
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberofObjectives', 'GlobalID', 'SubActivity']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'SubActivity', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Objectives'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Objectives'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            subact = row[4] # Get the subactivity
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of objectives to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created
            
            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddWarning("There are " + str(extrarows) + " extra objective records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of objective records for this effort. Please manually delete the objective rows for this effort that not longer apply.")

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if newrec > 0:
                arcpy.AddMessage("New objectives records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " = " + str(newrec) + " records in " + outtable + ".")
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, subact, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor


###################################################################################################################################################
### Methods
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberofMethods', 'GlobalID', 'SubActivity']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'SubActivity', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Methods'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Methods'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            subact = row[4] # Get the subactivity
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddWarning("There are " + str(extrarows) + " extra method records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of method records for this effort. Please manually delete the method rows for this effort that not longer apply.")

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if newrec > 0:
                arcpy.AddMessage("New methods records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " = " + str(newrec) + " records in " + outtable + ".")
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, subact, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor


###################################################################################################################################################
### Effectiveness Statements
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberofEffectiveStates', 'GlobalID', 'Effect_Status', 'SubActivity']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'SubActivity', 'Effectiveness_Status', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Effectiveness_Statements'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Effectiveness_Statements'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            subact = row[5] # Get the subactivity
            effect = row[4] # Get the effectiveness
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records

            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
  
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddWarning("There are " + str(extrarows) + " extra Effectiveness Statements created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of effectiveness statement records for this effort. Please manually delete the effectiveness statement rows for this effort that not longer apply.")

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if newrec > 0:
                arcpy.AddMessage("New effectiveness statement records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " = " + str(newrec) + " records in " + outtable + ".")
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, subact, effect, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor


###################################################################################################################################################
### Collaborators
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberCollaborators', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script
    else:
        infields = ['Project_Name']
        with arcpy.da.SearchCursor(tbl, infields) as cursor:
            for row in cursor:
                prjname = row[0]
                cnt = 0
                for tbl1 in intables:
                    infields1 = ['Project_Name']
                    with arcpy.da.SearchCursor(tbl1, infields1) as cursor1:
                        for row1 in cursor1:
                            prjname1 = row1[0]

                            if prjname == prjname1:
                                cnt = cnt + 1
                if cnt > 1:
                    arcpy.AddError("Project Name '" + str(prjname) + "' is duplicated across multiple records in the 3 CED batch update main tables ('CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans'). Please ensure all efforts have unique project names. The error code is terminating.")
                    sys.exit()

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberCollaborators', 'GlobalID']

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Collaborators'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Collaborators'
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                outtable = 'CED_3_Child_Table_NonSpatial_Plan_Collaborators'

            NoneSel = 0

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(1) # Assign 0 if no data entered
                NoneSel = 1
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddWarning("There are " + str(extrarows) + " extra collaborator records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of collaborator records for this effort. Please manually delete the collaborator rows for this effort that not longer apply.")

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if NoneSel == 0:
                if newrec > 0:
                    arcpy.AddMessage("New collaborator records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " = " + str(newrec) + " records in " + outtable + ".")
                    cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                    
                    for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                        cursor1.insertRow((prjid, prjnm, gblid))

                    del cursor1 # Delete cursor1
                
            else:
                if newrec > 0: # Determine if new records need to be added to the table
                    arcpy.AddMessage("Null value entered for Collaborators. One new collaborator record created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " = " + str(newrec) + " records. This value will automatically be populated with a 'None' value indicating no Collaborators. No further action is needed on your part for this record.")
                    outfields1 = ['PrjID', 'PrjName', 'Collaborator', 'ParentGlobalID']
                    cursor1 = arcpy.da.InsertCursor(outtable, outfields1) #Set the Insert Cursor
                    
                    for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                        cursor1.insertRow((prjid, prjnm, 10, gblid))

                    del cursor1 # Delete cursor1

                elif existrec == 1:
                    outfields1 = ['PrjID', 'PrjName', 'Collaborator', 'ParentGlobalID']
                    with arcpy.da.UpdateCursor(outtable, outfields1, " PrjID = " + str(prjid) + " ") as cursor1:
                        for row1 in cursor1:
                            row1[2] = 10
                            cursor1.updateRow(row1) 
                    del cursor1

                else:
                    arcpy.AddWarning("For ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + ", you selected a Null value indicating None for collaborators in " + outtable + ". However, " + str(existrec) + " with data still exist, please delete all collaborator rows and run the tool again.")


    del cursor  # Delete cursor


###################################################################################################################################################
### Land Owners
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberLandOwners', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Land_Owners'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Land_Owners'
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                outtable = 'CED_3_Child_Table_NonSpatial_Plan_Land_Owners'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddWarning("There are " + str(extrarows) + " extra land owner records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of land owner records for this effort. Please manually delete the land owner rows for this effort that not longer apply.")

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if newrec > 0: # Determine if new records need to be added to the table
                arcpy.AddMessage("New land ownership records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " = " + str(newrec) + " records in " + outtable + ".")
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor

###################################################################################################################################################
### Threats
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberThreatsAddress', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects', 'CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Spatial_Project_Threats'
            elif tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Threats'
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                outtable = 'CED_3_Child_Table_NonSpatial_Plan_Threats'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddWarning("There are " + str(extrarows) + " extra threat records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of threat records for this effort. Please manually delete the threat rows for this effort that not longer apply.")

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if newrec > 0: # Determine if new records need to be added to the table

                arcpy.AddMessage("New threat records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " = " + str(newrec) + " records in " + outtable + ".")
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor

###################################################################################################################################################
### Effectiveness PECE
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'Effect_Status', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Effectiveness_PECE_Questions'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                eff = int(row[2]) # Get the number of threats to be created for the project
            except:
                eff = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable

            if existrec > 0: 
                if eff == 1:
                    arcpy.DeleteRows_management("outtable_view")
                    arcpy.AddWarning("Effectiveness PECE record exists and is no longer required for ID: " + str(prjid) + ", Name: " + str(prjnm) + ", and Global ID: " + str(gblid) + ". The record has been deleted.")
                elif eff == 2 or eff == 3:
                    arcpy.AddWarning("Effectiveness PECE record alread exists for ID: " + str(prjid) + ", Name: " + str(prjnm) + ", and Global ID: " + str(gblid) + ". A new record cannot be created.")
            else:
                if eff == 1:
                    arcpy.AddWarning("Effectiveness PECE record is not required for ID: " + str(prjid) + ", Name: " + str(prjnm) + ", and Global ID: " + str(gblid) + ".")
                elif eff == 2 or eff == 3:
                    cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                    cursor1.insertRow((prjid, prjnm, gblid))
                    del cursor1 # Delete cursor1
                    arcpy.AddMessage("New effectiveness PECE record created for ID: " + str(prjid) + ", Name: " + str(prjnm) + ", and Global ID: " + str(gblid))

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view
                
            

    del cursor  # Delete cursor

###################################################################################################################################################
### Implementation PECE
###################################################################################################################################################

# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'Entry_Status', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_1_Batch_Template_Spatial_Projects']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script

# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_1_Batch_Template_Spatial_Projects': #Set the appropriate out table
                outtable = 'CED_1_Child_Table_Implementation_PECE_Questions'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                imp = int(row[2]) # Get the number of threats to be created for the project
            except:
                imp = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable

            if existrec > 0: 
                if imp == 3:
                    arcpy.DeleteRows_management("outtable_view")
                    arcpy.AddWarning("Implementation PECE record exists and is no longer required for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + ". The record has been deleted.")
                elif imp == 2:
                    arcpy.AddWarning("Implementation PECE record alread exists for ID: " + str(prjid) + ", Name: " + str(prjnm) + ", and Global ID: " + str(gblid) + ". A new record cannot be created.")
            else:
                if imp == 3:
                    arcpy.AddWarning("Implementation PECE record is not required for ID: " + str(prjid) + ", Name: " + str(prjnm) + ", and Global ID: " + str(gblid) + ".")
                elif imp == 2:
                    cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                    cursor1.insertRow((prjid, prjnm, gblid))
                    del cursor1 # Delete cursor1
                    arcpy.AddMessage("New implementation PECE record created for ID: " + str(prjid) + ", Name: " + str(prjnm) + ", and Global ID: " + str(gblid))

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view
                
            

    del cursor  # Delete cursor

###################################################################################################################################################
### Counties
###################################################################################################################################################
# Field names needed to extract specific threat information from the intables
infields = ['OBJECTID', 'Project_Name', 'NumberCounties', 'GlobalID']

arcpy.env.workspace = gdb

# Specify the in tables where number of threats per record are recorded
intables = ['CED_2_Batch_Template_NonSpatial_Projects', 'CED_3_Batch_Template_NonSpatial_Plans']

for tbl in intables: # Double check to ensure all parent tables still exist
    if arcpy.Exists(tbl) == False: # Look for the parent table
        arcpy.AddError('Error: Not all CED parent tables could not be be found. Please ensure you are uploading the correct file geodatabase. The process is terminated.') # Add an error message if the table doesn't exist
        sys.exit() # Exit the script


# Field names needed to input specific threat information to the outtables
outfields = ['PrjID', 'PrjName', 'ParentGlobalID']

for tbl in intables: #Loop through all the input tables
    with arcpy.da.SearchCursor(tbl, infields) as cursor:
        for row in cursor:
            if tbl == 'CED_2_Batch_Template_NonSpatial_Projects':
                outtable = 'CED_2_Child_Table_NonSpatial_Project_Counties'
            elif tbl == 'CED_3_Batch_Template_NonSpatial_Plans':
                outtable = 'CED_3_Child_Table_NonSpatial_Plan_Counties'

            prjid = int(row[0]) # Get the project ObjectID
            prjnm = row[1] # Get the project name
            if str(row[1]) == "None":
                arcpy.AddError("Project Name does not exist in table: " + tbl + ". Please ensure all efforts have project names. The record generation code is terminating. Please ensure all records have project names.")
                sys.exit()
            try:
                totrec = int(row[2]) # Get the number of threats to be created for the project
            except:
                totrec = int(0) # Assign 0 if no data entered
            gblid = str(row[3]) # Get the parent Global ID for the effort

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            arcpy.MakeTableView_management(outtable, "outtable_view") # Create a table view from the records
            arcpy.SelectLayerByAttribute_management ("outtable_view", "NEW_SELECTION", " PrjID = " + str(prjid)) # Select the table by the current Project ID to determine the number of records
            result = arcpy.GetCount_management("outtable_view") # Get the count of existing records
            existrec = int(result[0]) # Get the count of existing records as a variable
            newrec = totrec - existrec # Determine the number of new records that need to be created

            if newrec < 0:
                extrarows = newrec * -1
                arcpy.AddWarning("There are " + str(extrarows) + " extra county records created for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " in " + outtable + ". You must have reduced the number of county records for this effort. Please manually delete the county rows for this effort that not longer apply.")

            if arcpy.Exists("outtable_view"): # If the table view exists
                arcpy.Delete_management("outtable_view") # Delete the table view

            if newrec > 0: # Determine if new records need to be added to the table

                arcpy.AddMessage("New county records created in " + outtable + " for ID: " + str(prjid) + ", Name: " + str(prjnm)  + ", and Global ID: " + str(gblid) + " = " + str(newrec) + " records")
                cursor1 = arcpy.da.InsertCursor(outtable, outfields) #Set the Insert Cursor
                
                for x in range(0, newrec): # Create and properly attribute a row for each threat addressed
                    cursor1.insertRow((prjid, prjnm, gblid))

                del cursor1 # Delete cursor1

    del cursor  # Delete cursor

arcpy.AddMessage("Script completed successfully. Please review all messages, warnings, and errors that may be present in the results window.")


